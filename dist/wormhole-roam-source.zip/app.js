export default {onLaunch(){},globalData:{}};
